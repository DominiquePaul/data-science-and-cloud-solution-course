# your turn!


# 1. load the boston housing set (data --> housing.csv) and into a dataframe and
#    try to understand what each of the columns means
### your code below this line ###


### your code above this line ###



# 2. select a subset of your data and create some plots of the distributions
#    using the seaborn package. Try to understand which of the features might
#    have the strongest impact on the price (='medv' column)
### your code below this line ###


### your code above this line ###



# 3. Create a subset of the data using three features and split the data into
#    a training and testing set. Before you do so, however, shuffle the data
#    by using the iloc function together with a list of the shuffled row ids.
#    Have a look at the numpy package for useful functions
### your code below this line ###


### your code above this line ###



# 4. Run a multiple linear regression using the statsmodel package and print
#    the summary of your regression. Comment on your results
### your code below this line ###


### your code above this line ###




# 5. Create three scatterplots for each of your chosen three features and the
#    price on the y-axis. Plot your predictions as well as the actual labels, but use different colours
### your code below this line ###


### your code above this line ###



# 6. Save one of your plots to your local directory
### your code below this line ###


### your code above this line ###
